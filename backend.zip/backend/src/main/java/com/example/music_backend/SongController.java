package com.example.musicbackend;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@RestController
public class SongController {
    @Autowired
    private SongRepository repo;

    @GetMapping("/songs")
    public List<Song> getSongs() {
        return repo.findAll();
    }
}

interface SongRepository extends JpaRepository<Song, Long> {}